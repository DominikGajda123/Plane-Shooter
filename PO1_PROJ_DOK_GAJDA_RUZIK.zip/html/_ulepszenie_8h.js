var _ulepszenie_8h =
[
    [ "Ulepszenie", "struct_ulepszenie.html", "struct_ulepszenie" ],
    [ "TypUlepszenia", "_ulepszenie_8h.html#af39aa1cab4aeea2c0c1468bda978b257", [
      [ "Szybkostrzelnosc", "_ulepszenie_8h.html#af39aa1cab4aeea2c0c1468bda978b257a32f42c1283849a1ed3dfd335d70f228a", null ],
      [ "Tarcza", "_ulepszenie_8h.html#af39aa1cab4aeea2c0c1468bda978b257a4d0e40f54b8dd8601cb225c3165ffbfe", null ],
      [ "PodwojnyStrzal", "_ulepszenie_8h.html#af39aa1cab4aeea2c0c1468bda978b257ac44670b5eba192670a951b77e3aa8e3d", null ],
      [ "DodatkoweZycie", "_ulepszenie_8h.html#af39aa1cab4aeea2c0c1468bda978b257af49bc62eb72f3ac87f676c08fca18e78", null ]
    ] ]
];