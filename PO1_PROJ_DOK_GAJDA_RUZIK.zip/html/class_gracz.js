var class_gracz =
[
    [ "Gracz", "class_gracz.html#ad7e7c3df42e8fac5e352627c79622607", null ],
    [ "aktualizujPozycjeTarczy", "class_gracz.html#aa357722b05e96451c0c8417e53bf8e12", null ],
    [ "maTarcze", "class_gracz.html#a5d0b427098e06c8c1bb7c7a854eb3729", null ],
    [ "obslugaRuchu", "class_gracz.html#a4fb11a3721051b50727d43474647c80a", null ],
    [ "ograniczDoEkranu", "class_gracz.html#aac22b889e02757c88ce19be94b2f52f9", null ],
    [ "otrzymajObrazenia", "class_gracz.html#ac006d58f6056ad4306783477d080a7c6", null ],
    [ "pobierzGranice", "class_gracz.html#a7f823f7828b76fb2bdc47d4c5d029b9d", null ],
    [ "pobierzMaxZycia", "class_gracz.html#ae414f0c75a2fa3c682e2a887c9c5286b", null ],
    [ "pobierzPozycje", "class_gracz.html#a0265a12a5363e90f4c03b42236b4b33b", null ],
    [ "pobierzZycia", "class_gracz.html#ae0c62fb7a52113a3575ab1a799fa1d14", null ],
    [ "rysuj", "class_gracz.html#a7346d7415cbc90b3aed65f256bbf32f9", null ],
    [ "ulecz", "class_gracz.html#a327722c2a5859aa715e944901e9a7418", null ],
    [ "wlaczTarcze", "class_gracz.html#a50b19c625302dbbd158743c6f2665c75", null ],
    [ "maxZycia", "class_gracz.html#aa7a1e4c5112dae462a8e5baafdc0502d", null ],
    [ "obwodkaTarczy", "class_gracz.html#a49ed63bc08345b6d503890d56addefc6", null ],
    [ "predkosc", "class_gracz.html#a757b01d6bfe711a908b8c7d8b7d9d49e", null ],
    [ "sprite", "class_gracz.html#a1fa58704903957de2ff812a1cf098cfc", null ],
    [ "tarcza", "class_gracz.html#ab9e55950056163ea55213f4f8a568af0", null ],
    [ "zycia", "class_gracz.html#a292f1d8206e4ec48f5be43471dc9c950", null ]
];