var class_enemy =
[
    [ "Typ", "class_enemy.html#ab34be07fea4b4823b5d709787552e00d", [
      [ "Meteoryt", "class_enemy.html#ab34be07fea4b4823b5d709787552e00daf16cca7bc824777be1795263d146a944", null ],
      [ "Statek", "class_enemy.html#ab34be07fea4b4823b5d709787552e00dabb02f7d89325803f159ee0ca32de687e", null ]
    ] ],
    [ "Enemy", "class_enemy.html#a795d4fbbe7ed2d870f014085125a0b0d", null ],
    [ "aktualizacja", "class_enemy.html#a9f3f3cea8c9e7caf78978723e3bc8e06", null ],
    [ "czyMartwy", "class_enemy.html#a1790768f87e6f6ec9bd03307d12c247f", null ],
    [ "otrzymajObrazenia", "class_enemy.html#a3f69ec0be2f5bfc1b0fa034ea2e1590e", null ],
    [ "pobierzGranice", "class_enemy.html#a406547a3419b00cb9921e33b45255a6b", null ],
    [ "pobierzPozycjeStrzalu", "class_enemy.html#a50f029b161b84ed2e63bf80b3e6ed1d5", null ],
    [ "pobierzTyp", "class_enemy.html#a6ec8228ee53b701a28bb6417361870e9", null ],
    [ "pozaEkranem", "class_enemy.html#ae242da29ac75be9c96c2c86ad7eec77f", null ],
    [ "rysuj", "class_enemy.html#a049ffbd614ef16d54bbc9112e4b473a9", null ],
    [ "hp", "class_enemy.html#a278d70100af07c946743db1b7a1a9f59", null ],
    [ "predkosc", "class_enemy.html#adc5332139c6f90fae9e66d52fcb54e0c", null ],
    [ "sprite", "class_enemy.html#a58f0472dce634e0e04d42c3ffe3dda6f", null ],
    [ "typ", "class_enemy.html#adbf79b83e822c401f5ca36823d413f05", null ]
];