var annotated_dup =
[
    [ "Boss", "class_boss.html", "class_boss" ],
    [ "Eksplozja", "class_eksplozja.html", "class_eksplozja" ],
    [ "Enemy", "class_enemy.html", "class_enemy" ],
    [ "Gra", "class_gra.html", "class_gra" ],
    [ "Gracz", "class_gracz.html", "class_gracz" ],
    [ "Pocisk", "class_pocisk.html", "class_pocisk" ],
    [ "PociskBazowy", "class_pocisk_bazowy.html", "class_pocisk_bazowy" ],
    [ "PociskWroga", "class_pocisk_wroga.html", "class_pocisk_wroga" ],
    [ "Ulepszenie", "struct_ulepszenie.html", "struct_ulepszenie" ],
    [ "Zasoby", "class_zasoby.html", "class_zasoby" ]
];