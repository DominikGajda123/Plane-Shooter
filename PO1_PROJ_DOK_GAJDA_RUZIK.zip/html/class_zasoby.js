var class_zasoby =
[
    [ "pobierzTeksture", "class_zasoby.html#aa79022b493022c4397f75aa9f1b62665", null ],
    [ "wczytajTeksture", "class_zasoby.html#a18123c0eaa8585b14cf962741ddf8b3d", null ],
    [ "tekstury", "class_zasoby.html#ad429eccfc67dfa6a51d5c030497eceea", null ]
];