var class_boss =
[
    [ "Boss", "class_boss.html#a7be7ddd42c69cd75032b1956eab7db88", null ],
    [ "aktualizacja", "class_boss.html#a63f8ddda67b3b986c9efc500c0f60eb6", null ],
    [ "czyMartwy", "class_boss.html#ab3709c49651f38fffd6b7341a560eb47", null ],
    [ "otrzymajObrazenia", "class_boss.html#a2d671a54bd265e040aaf0aa056a50d9f", null ],
    [ "pobierzGranice", "class_boss.html#a672e6f235b7bc3a7103dc89440ce493f", null ],
    [ "pobierzHp", "class_boss.html#a15a1bf970f8c241932bf31b06f47fc28", null ],
    [ "pobierzMaxHp", "class_boss.html#a777c8407c8d53eea3f93fa8c61b1ebc8", null ],
    [ "pobierzSrodek", "class_boss.html#a074f8cd1eb6bc2f06084e34a00b2f3be", null ],
    [ "rysuj", "class_boss.html#a9ebbd4cc89ccef455abd75aabfdb7608", null ],
    [ "hp", "class_boss.html#a0517628e5cdd82ee25abae40f0fc3b34", null ],
    [ "maxHp", "class_boss.html#a1837495e48c9d31b2615d54ea8f951e8", null ],
    [ "predkoscX", "class_boss.html#a5519ce096ccc5dc1cd1b65db6f6450e2", null ],
    [ "sprite", "class_boss.html#ab6468dd416137e07fa62f3f1155024e5", null ]
];