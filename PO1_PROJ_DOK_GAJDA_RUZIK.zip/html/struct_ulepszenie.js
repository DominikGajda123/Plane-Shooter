var struct_ulepszenie =
[
    [ "Ulepszenie", "struct_ulepszenie.html#a974c3e7035390493de7341b2eea13155", null ],
    [ "aktualizacja", "struct_ulepszenie.html#a31e0945141d3f6cadc0c567e1b0de33e", null ],
    [ "pobierzGranice", "struct_ulepszenie.html#abdce7335da30a2112a7a104524cc98a6", null ],
    [ "pozaEkranem", "struct_ulepszenie.html#ae680bc61fadc32c0a88a9c65e9264567", null ],
    [ "rysuj", "struct_ulepszenie.html#a51c5e3feb0f7abbd78148e3400e5b91f", null ],
    [ "aktywne", "struct_ulepszenie.html#a7fbf8d5537cda8f30a411321af251896", null ],
    [ "ksztalt", "struct_ulepszenie.html#a1428eba001ae9e49b7577a7a2d04421d", null ],
    [ "predkosc", "struct_ulepszenie.html#aea62494c49f4f999f2c18abbff84582e", null ],
    [ "typ", "struct_ulepszenie.html#a5685025ae74bc7acea0b16aa5a57333d", null ]
];