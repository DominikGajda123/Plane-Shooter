var class_eksplozja =
[
    [ "Eksplozja", "class_eksplozja.html#a51a5a4c5d7aaac11b5a3a7316faf10bf", null ],
    [ "aktualizacja", "class_eksplozja.html#a6e6785f31d7be037af826c8a71034483", null ],
    [ "czyZakonczona", "class_eksplozja.html#adf687c10e9fbeea0d20b819f5d9e9717", null ],
    [ "rysuj", "class_eksplozja.html#a600e7d61072e9cc372136b5acf4be70a", null ],
    [ "ustawOriginNaSrodek", "class_eksplozja.html#ab069a88f4343123e8671952684a9f523", null ],
    [ "aktualnaKlatka", "class_eksplozja.html#a284225b99b720d9f31ea42100edc5a73", null ],
    [ "czas", "class_eksplozja.html#aefa73c6625c5f7371bc71da4cb9609de", null ],
    [ "czasKlatki", "class_eksplozja.html#a7f134a1e61b9e80549c1e0974b04a753", null ],
    [ "klatki", "class_eksplozja.html#aea6aebbdbd8aad0a585475daa9a8059b", null ],
    [ "sprite", "class_eksplozja.html#a3f7cc04f76836c0bbae057470d8f7749", null ],
    [ "zakonczono", "class_eksplozja.html#a02361b1b3822da636d903f36d27a0b4d", null ]
];