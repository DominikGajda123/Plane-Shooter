var hierarchy =
[
    [ "Boss", "class_boss.html", null ],
    [ "Eksplozja", "class_eksplozja.html", null ],
    [ "Enemy", "class_enemy.html", null ],
    [ "Gra", "class_gra.html", null ],
    [ "Gracz", "class_gracz.html", null ],
    [ "PociskBazowy", "class_pocisk_bazowy.html", [
      [ "Pocisk", "class_pocisk.html", null ],
      [ "PociskWroga", "class_pocisk_wroga.html", null ]
    ] ],
    [ "Ulepszenie", "struct_ulepszenie.html", null ],
    [ "Zasoby", "class_zasoby.html", null ]
];