var class_pocisk_bazowy =
[
    [ "PociskBazowy", "class_pocisk_bazowy.html#af41b1150b14ea8220014b76c89f23087", null ],
    [ "aktualizacja", "class_pocisk_bazowy.html#a49aaaff038d04848459675a113a2784c", null ],
    [ "czyAktywny", "class_pocisk_bazowy.html#ab9cf85d8987ba74ac95be2dee4614292", null ],
    [ "dezaktywuj", "class_pocisk_bazowy.html#a6dfe140d285f07503404e1b397a4d896", null ],
    [ "pobierzGranice", "class_pocisk_bazowy.html#a7916e00ea94187f37d9278145810fac9", null ],
    [ "rysuj", "class_pocisk_bazowy.html#a082bf1058e2f8477b46c61fc5856d39a", null ],
    [ "aktywny", "class_pocisk_bazowy.html#a99cf2793e71d35c00219bb03d9b33439", null ],
    [ "ksztalt", "class_pocisk_bazowy.html#a02c6cea46093c5eadd1008ab29c3d2a1", null ],
    [ "predkosc", "class_pocisk_bazowy.html#a218f34818bf1a66152759bab3b95c438", null ]
];