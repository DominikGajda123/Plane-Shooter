var searchData=
[
  ['ulecz_0',['ulecz',['../class_gracz.html#a327722c2a5859aa715e944901e9a7418',1,'Gracz']]],
  ['ulepszenie_1',['Ulepszenie',['../struct_ulepszenie.html#a974c3e7035390493de7341b2eea13155',1,'Ulepszenie']]],
  ['uruchom_2',['uruchom',['../class_gra.html#a7e151721f57b23eebbf551ac6413cd8c',1,'Gra']]],
  ['ustaworiginnasrodek_3',['ustawOriginNaSrodek',['../class_eksplozja.html#ab069a88f4343123e8671952684a9f523',1,'Eksplozja']]],
  ['usuneksplozje_4',['usunEksplozje',['../class_gra.html#ab40459f8d40e456424922b2f775f5673',1,'Gra']]],
  ['usunnieaktywneobiekty_5',['usunNieaktywneObiekty',['../class_gra.html#a1aea65384bad0e9ed486d82cadc788b8',1,'Gra']]],
  ['usunpociski_6',['usunPociski',['../class_gra.html#af4035df5e7b2832fabd69110fd0d67d7',1,'Gra']]],
  ['usunpociskiwrogow_7',['usunPociskiWrogow',['../class_gra.html#a959a4f0c764d8f4c7fb145db61d6d3e9',1,'Gra']]],
  ['usunprzeciwnikow_8',['usunPrzeciwnikow',['../class_gra.html#aef5f02bf0c651cf46dc9028a74447dfa',1,'Gra']]],
  ['usunulepszenia_9',['usunUlepszenia',['../class_gra.html#ae8c511208c232ac9803ce61a642b6b2f',1,'Gra']]]
];
