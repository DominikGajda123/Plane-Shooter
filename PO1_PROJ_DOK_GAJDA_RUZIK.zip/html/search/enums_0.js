var searchData=
[
  ['typ_0',['Typ',['../class_enemy.html#ab34be07fea4b4823b5d709787552e00d',1,'Enemy']]],
  ['typulepszenia_1',['TypUlepszenia',['../_ulepszenie_8h.html#af39aa1cab4aeea2c0c1468bda978b257',1,'Ulepszenie.h']]]
];
