var searchData=
[
  ['tarcza_0',['tarcza',['../class_gracz.html#ab9e55950056163ea55213f4f8a568af0',1,'Gracz']]],
  ['tekstgameover_1',['tekstGameOver',['../class_gra.html#a1c9dcb3cb1e34c949b1cac4f5dd64a5f',1,'Gra']]],
  ['tekstscore_2',['tekstScore',['../class_gra.html#a095b02d22dadf81046848fac82e72c8c',1,'Gra']]],
  ['tekstury_3',['tekstury',['../class_zasoby.html#ad429eccfc67dfa6a51d5c030497eceea',1,'Zasoby']]],
  ['tlo_4',['tlo',['../class_gra.html#a6155006e6a272abcf254b0e351dd491c',1,'Gra']]],
  ['typ_5',['typ',['../class_enemy.html#adbf79b83e822c401f5ca36823d413f05',1,'Enemy::typ'],['../struct_ulepszenie.html#a5685025ae74bc7acea0b16aa5a57333d',1,'Ulepszenie::typ']]]
];
