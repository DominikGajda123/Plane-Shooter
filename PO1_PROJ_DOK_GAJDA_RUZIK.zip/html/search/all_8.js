var searchData=
[
  ['klatki_0',['klatki',['../class_eksplozja.html#aea6aebbdbd8aad0a585475daa9a8059b',1,'Eksplozja']]],
  ['klatkieksplozji_1',['klatkiEksplozji',['../class_gra.html#aa1e1665a1dd373328ab70daf5145fdad',1,'Gra']]],
  ['ksztalt_2',['ksztalt',['../class_pocisk_bazowy.html#a02c6cea46093c5eadd1008ab29c3d2a1',1,'PociskBazowy::ksztalt'],['../struct_ulepszenie.html#a1428eba001ae9e49b7577a7a2d04421d',1,'Ulepszenie::ksztalt']]]
];
