var searchData=
[
  ['ulepszenie_2ecpp_0',['Ulepszenie.cpp',['../_ulepszenie_8cpp.html',1,'']]],
  ['ulepszenie_2eh_1',['Ulepszenie.h',['../_ulepszenie_8h.html',1,'']]]
];
