var searchData=
[
  ['boss_0',['boss',['../class_gra.html#a1230f01caa1ea5ddaa868ec3b2ad3b6c',1,'Gra']]],
  ['buforkonca_1',['buforKonca',['../class_gra.html#ab9c46752421e0dcbf61e7cfa0d9cce73',1,'Gra']]],
  ['buforstrzalu_2',['buforStrzalu',['../class_gra.html#a80a01b508e253bf8ffe45643710e3e54',1,'Gra']]],
  ['buforwybuchu_3',['buforWybuchu',['../class_gra.html#af00ee84be3696bc5da20bbc582e9eb46',1,'Gra']]]
];
