var searchData=
[
  ['czyaktywny_0',['czyAktywny',['../class_pocisk_bazowy.html#ab9cf85d8987ba74ac95be2dee4614292',1,'PociskBazowy']]],
  ['czymartwy_1',['czyMartwy',['../class_boss.html#ab3709c49651f38fffd6b7341a560eb47',1,'Boss::czyMartwy()'],['../class_enemy.html#a1790768f87e6f6ec9bd03307d12c247f',1,'Enemy::czyMartwy()']]],
  ['czyulepszeniedostepne_2',['czyUlepszenieDostepne',['../class_gra.html#a903996afc3794aa4fd2e14a925ac7533',1,'Gra']]],
  ['czyzakonczona_3',['czyZakonczona',['../class_eksplozja.html#adf687c10e9fbeea0d20b819f5d9e9717',1,'Eksplozja']]]
];
