var searchData=
[
  ['ulepszenia_0',['ulepszenia',['../class_gra.html#a18f76d7ab78b5a9a8b5fb8fbeda6aa0f',1,'Gra']]]
];
