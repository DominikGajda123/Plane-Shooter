var searchData=
[
  ['obwodkatarczy_0',['obwodkaTarczy',['../class_gracz.html#a49ed63bc08345b6d503890d56addefc6',1,'Gracz']]],
  ['okno_1',['okno',['../class_gra.html#a8d3738d0cb9919e269b4425db8e70a75',1,'Gra']]]
];
