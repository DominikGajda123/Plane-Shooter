var searchData=
[
  ['gra_0',['Gra',['../class_gra.html#a85a3fce34f62b6e87fbe6e9cf2419ca7',1,'Gra']]],
  ['gracz_1',['Gracz',['../class_gracz.html#ad7e7c3df42e8fac5e352627c79622607',1,'Gracz']]]
];
