var searchData=
[
  ['score_0',['score',['../class_gra.html#ad71728b9ca370359ef5aeb6a2c94082d',1,'Gra']]],
  ['serduszka_1',['serduszka',['../class_gra.html#ad7c49a0e37ccbc1f000289cdb6294107',1,'Gra']]],
  ['sprite_2',['sprite',['../class_boss.html#ab6468dd416137e07fa62f3f1155024e5',1,'Boss::sprite'],['../class_eksplozja.html#a3f7cc04f76836c0bbae057470d8f7749',1,'Eksplozja::sprite'],['../class_gracz.html#a1fa58704903957de2ff812a1cf098cfc',1,'Gracz::sprite'],['../class_enemy.html#a58f0472dce634e0e04d42c3ffe3dda6f',1,'Enemy::sprite']]],
  ['szybkiepociski_3',['szybkiePociski',['../class_gra.html#a684864d85c5405d61fb6843e5968d668',1,'Gra']]]
];
