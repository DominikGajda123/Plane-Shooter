var searchData=
[
  ['obslugaruchu_0',['obslugaRuchu',['../class_gracz.html#a4fb11a3721051b50727d43474647c80a',1,'Gracz']]],
  ['obslugazdarzen_1',['obslugaZdarzen',['../class_gra.html#a41df71aa95540a91ba6cdbae21b90f12',1,'Gra']]],
  ['obwodkatarczy_2',['obwodkaTarczy',['../class_gracz.html#a49ed63bc08345b6d503890d56addefc6',1,'Gracz']]],
  ['ograniczdoekranu_3',['ograniczDoEkranu',['../class_gracz.html#aac22b889e02757c88ce19be94b2f52f9',1,'Gracz']]],
  ['okno_4',['okno',['../class_gra.html#a8d3738d0cb9919e269b4425db8e70a75',1,'Gra']]],
  ['otrzymajobrazenia_5',['otrzymajObrazenia',['../class_boss.html#a2d671a54bd265e040aaf0aa056a50d9f',1,'Boss::otrzymajObrazenia()'],['../class_gracz.html#ac006d58f6056ad4306783477d080a7c6',1,'Gracz::otrzymajObrazenia()'],['../class_enemy.html#a3f69ec0be2f5bfc1b0fa034ea2e1590e',1,'Enemy::otrzymajObrazenia()']]]
];
