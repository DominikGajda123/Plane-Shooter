var searchData=
[
  ['spawnprzeciwnika_0',['spawnPrzeciwnika',['../class_gra.html#ad951b777d75cd447edf71f69738218cf',1,'Gra']]],
  ['spawnulepszenia_1',['spawnUlepszenia',['../class_gra.html#ab936b23eefc62ebf00ed2e0027724f16',1,'Gra']]],
  ['sprawdzkolizje_2',['sprawdzKolizje',['../class_gra.html#a574512a49307975a3ca4c0528f9ed3bc',1,'Gra']]],
  ['sprawdzkolizjegraczazprzeciwnikami_3',['sprawdzKolizjeGraczaZPrzeciwnikami',['../class_gra.html#ab629b8275d0f5002f8a23a6f9268ea8d',1,'Gra']]],
  ['sprawdzkolizjepociskowwrogow_4',['sprawdzKolizjePociskowWrogow',['../class_gra.html#a5208b2ce4a5728a30fe8ff43da7c2128',1,'Gra']]],
  ['sprawdzkolizjepociskowzbossem_5',['sprawdzKolizjePociskowZBossem',['../class_gra.html#ad98046940ecc40b33eaff81fda3676af',1,'Gra']]],
  ['sprawdzkolizjepociskowzprzeciwnikami_6',['sprawdzKolizjePociskowZPrzeciwnikami',['../class_gra.html#ad325f4b3ee8dc7dfca94d0483faf1b84',1,'Gra']]],
  ['sprawdzkolizjeulepszen_7',['sprawdzKolizjeUlepszen',['../class_gra.html#a749da49c26093fe4fb42040603d18631',1,'Gra']]],
  ['sprawdzkoniecgry_8',['sprawdzKoniecGry',['../class_gra.html#ad1de155c894c282de8856ef554bac425',1,'Gra']]],
  ['sprawdzstartbossa_9',['sprawdzStartBossa',['../class_gra.html#a0e784e99ab6b91aff7dc6b1a7a159e1d',1,'Gra']]],
  ['strzalbossa_10',['strzalBossa',['../class_gra.html#a381c9e3380cba771f901e75b12e2f92d',1,'Gra']]],
  ['strzalwrogow_11',['strzalWrogow',['../class_gra.html#a233373a739d5593bdf8813209eaafa9c',1,'Gra']]],
  ['strzel_12',['strzel',['../class_gra.html#ac22124301ea361e38d4b9e0df79ba9c5',1,'Gra']]]
];
