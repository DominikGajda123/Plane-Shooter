var searchData=
[
  ['podwojnystrzal_0',['PodwojnyStrzal',['../_ulepszenie_8h.html#af39aa1cab4aeea2c0c1468bda978b257ac44670b5eba192670a951b77e3aa8e3d',1,'Ulepszenie.h']]]
];
