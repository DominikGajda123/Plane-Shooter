var searchData=
[
  ['tarcza_0',['Tarcza',['../_ulepszenie_8h.html#af39aa1cab4aeea2c0c1468bda978b257a4d0e40f54b8dd8601cb225c3165ffbfe',1,'Ulepszenie.h']]],
  ['tarcza_1',['tarcza',['../class_gracz.html#ab9e55950056163ea55213f4f8a568af0',1,'Gracz']]],
  ['tekstgameover_2',['tekstGameOver',['../class_gra.html#a1c9dcb3cb1e34c949b1cac4f5dd64a5f',1,'Gra']]],
  ['tekstscore_3',['tekstScore',['../class_gra.html#a095b02d22dadf81046848fac82e72c8c',1,'Gra']]],
  ['tekstury_4',['tekstury',['../class_zasoby.html#ad429eccfc67dfa6a51d5c030497eceea',1,'Zasoby']]],
  ['tlo_5',['tlo',['../class_gra.html#a6155006e6a272abcf254b0e351dd491c',1,'Gra']]],
  ['typ_6',['Typ',['../class_enemy.html#ab34be07fea4b4823b5d709787552e00d',1,'Enemy']]],
  ['typ_7',['typ',['../class_enemy.html#adbf79b83e822c401f5ca36823d413f05',1,'Enemy::typ'],['../struct_ulepszenie.html#a5685025ae74bc7acea0b16aa5a57333d',1,'Ulepszenie::typ']]],
  ['typulepszenia_8',['TypUlepszenia',['../_ulepszenie_8h.html#af39aa1cab4aeea2c0c1468bda978b257',1,'Ulepszenie.h']]]
];
