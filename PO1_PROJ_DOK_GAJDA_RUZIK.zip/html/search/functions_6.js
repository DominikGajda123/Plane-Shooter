var searchData=
[
  ['losujint_0',['losujInt',['../class_gra.html#a3a19fd4fd8d81cee8a393421fb4e8985',1,'Gra']]]
];
