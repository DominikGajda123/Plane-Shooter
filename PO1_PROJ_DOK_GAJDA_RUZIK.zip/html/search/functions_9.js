var searchData=
[
  ['pobierzgranice_0',['pobierzGranice',['../class_boss.html#a672e6f235b7bc3a7103dc89440ce493f',1,'Boss::pobierzGranice()'],['../class_gracz.html#a7f823f7828b76fb2bdc47d4c5d029b9d',1,'Gracz::pobierzGranice()'],['../class_pocisk_bazowy.html#a7916e00ea94187f37d9278145810fac9',1,'PociskBazowy::pobierzGranice()'],['../class_enemy.html#a406547a3419b00cb9921e33b45255a6b',1,'Enemy::pobierzGranice()'],['../struct_ulepszenie.html#abdce7335da30a2112a7a104524cc98a6',1,'Ulepszenie::pobierzGranice()']]],
  ['pobierzhp_1',['pobierzHp',['../class_boss.html#a15a1bf970f8c241932bf31b06f47fc28',1,'Boss']]],
  ['pobierzmaxhp_2',['pobierzMaxHp',['../class_boss.html#a777c8407c8d53eea3f93fa8c61b1ebc8',1,'Boss']]],
  ['pobierzmaxzycia_3',['pobierzMaxZycia',['../class_gracz.html#ae414f0c75a2fa3c682e2a887c9c5286b',1,'Gracz']]],
  ['pobierzpozycje_4',['pobierzPozycje',['../class_gracz.html#a0265a12a5363e90f4c03b42236b4b33b',1,'Gracz']]],
  ['pobierzpozycjestrzalu_5',['pobierzPozycjeStrzalu',['../class_enemy.html#a50f029b161b84ed2e63bf80b3e6ed1d5',1,'Enemy']]],
  ['pobierzsrodek_6',['pobierzSrodek',['../class_boss.html#a074f8cd1eb6bc2f06084e34a00b2f3be',1,'Boss']]],
  ['pobierzteksture_7',['pobierzTeksture',['../class_zasoby.html#aa79022b493022c4397f75aa9f1b62665',1,'Zasoby']]],
  ['pobierztyp_8',['pobierzTyp',['../class_enemy.html#a6ec8228ee53b701a28bb6417361870e9',1,'Enemy']]],
  ['pobierzzycia_9',['pobierzZycia',['../class_gracz.html#ae0c62fb7a52113a3575ab1a799fa1d14',1,'Gracz']]],
  ['pocisk_10',['Pocisk',['../class_pocisk.html#a6506e5a71a3692bf5c634311a062cf20',1,'Pocisk']]],
  ['pociskbazowy_11',['PociskBazowy',['../class_pocisk_bazowy.html#af41b1150b14ea8220014b76c89f23087',1,'PociskBazowy']]],
  ['pociskwroga_12',['PociskWroga',['../class_pocisk_wroga.html#ae6832470c24e41541ce89456944410ac',1,'PociskWroga::PociskWroga(sf::Vector2f pozycja)'],['../class_pocisk_wroga.html#a7d35d790ed8d968a7613c902e8899309',1,'PociskWroga::PociskWroga(sf::Vector2f pozycja, sf::Vector2f kierunek, float szybkosc)']]],
  ['pozaekranem_13',['pozaEkranem',['../class_pocisk.html#adb467a7b25dd744ddba2c0e241087008',1,'Pocisk::pozaEkranem()'],['../class_pocisk_wroga.html#a09009aa5d111109cef2e745ad59c6937',1,'PociskWroga::pozaEkranem()'],['../class_enemy.html#ae242da29ac75be9c96c2c86ad7eec77f',1,'Enemy::pozaEkranem()'],['../struct_ulepszenie.html#ae680bc61fadc32c0a88a9c65e9264567',1,'Ulepszenie::pozaEkranem()']]],
  ['przygotujaudio_14',['przygotujAudio',['../class_gra.html#a2a15a09e0e08c111b59efffe5f7ba223',1,'Gra']]],
  ['przygotujobiekty_15',['przygotujObiekty',['../class_gra.html#ac5cf5919f1c4910a1a785d2060de55a7',1,'Gra']]],
  ['przygotujui_16',['przygotujUI',['../class_gra.html#a95a0b123d54866cbbd33f9a42a9887ce',1,'Gra']]]
];
