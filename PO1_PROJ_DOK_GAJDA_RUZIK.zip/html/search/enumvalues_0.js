var searchData=
[
  ['dodatkowezycie_0',['DodatkoweZycie',['../_ulepszenie_8h.html#af39aa1cab4aeea2c0c1468bda978b257af49bc62eb72f3ac87f676c08fca18e78',1,'Ulepszenie.h']]]
];
