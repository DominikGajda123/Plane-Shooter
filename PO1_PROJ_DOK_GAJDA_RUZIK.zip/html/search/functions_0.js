var searchData=
[
  ['aktualizacja_0',['aktualizacja',['../class_boss.html#a63f8ddda67b3b986c9efc500c0f60eb6',1,'Boss::aktualizacja()'],['../class_eksplozja.html#a6e6785f31d7be037af826c8a71034483',1,'Eksplozja::aktualizacja()'],['../class_gra.html#af5d1aaac603acbe05ae88b374832e7ba',1,'Gra::aktualizacja()'],['../class_pocisk_bazowy.html#a49aaaff038d04848459675a113a2784c',1,'PociskBazowy::aktualizacja()'],['../class_enemy.html#a9f3f3cea8c9e7caf78978723e3bc8e06',1,'Enemy::aktualizacja()'],['../struct_ulepszenie.html#a31e0945141d3f6cadc0c567e1b0de33e',1,'Ulepszenie::aktualizacja()']]],
  ['aktualizujliczniki_1',['aktualizujLiczniki',['../class_gra.html#acd7a56ff5153fbbef07cd3e4f59d7f1c',1,'Gra']]],
  ['aktualizujobiekty_2',['aktualizujObiekty',['../class_gra.html#a7a6c0d3f14524beceaaf0be3c9a24682',1,'Gra']]],
  ['aktualizujpozycjetarczy_3',['aktualizujPozycjeTarczy',['../class_gracz.html#aa357722b05e96451c0c8417e53bf8e12',1,'Gracz']]],
  ['aktualizujui_4',['aktualizujUI',['../class_gra.html#a7dbd66054089dab02a5617444e079c1f',1,'Gra']]],
  ['aktywujulepszenie_5',['aktywujUlepszenie',['../class_gra.html#a9b077280b2a029d351d6c841be4b81db',1,'Gra']]]
];
