var searchData=
[
  ['nastepnybossscore_0',['nastepnyBossScore',['../class_gra.html#a91c366171b8c1e9338894d52bdddb811',1,'Gra']]]
];
