var searchData=
[
  ['wczytajteksture_0',['wczytajTeksture',['../class_zasoby.html#a18123c0eaa8585b14cf962741ddf8b3d',1,'Zasoby']]],
  ['wczytajzasoby_1',['wczytajZasoby',['../class_gra.html#ac969151ecf305cd1452e564de7a52d93',1,'Gra']]],
  ['wlacztarcze_2',['wlaczTarcze',['../class_gracz.html#a50b19c625302dbbd158743c6f2665c75',1,'Gracz']]]
];
