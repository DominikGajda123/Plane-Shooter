var searchData=
[
  ['obslugaruchu_0',['obslugaRuchu',['../class_gracz.html#a4fb11a3721051b50727d43474647c80a',1,'Gracz']]],
  ['obslugazdarzen_1',['obslugaZdarzen',['../class_gra.html#a41df71aa95540a91ba6cdbae21b90f12',1,'Gra']]],
  ['ograniczdoekranu_2',['ograniczDoEkranu',['../class_gracz.html#aac22b889e02757c88ce19be94b2f52f9',1,'Gracz']]],
  ['otrzymajobrazenia_3',['otrzymajObrazenia',['../class_boss.html#a2d671a54bd265e040aaf0aa056a50d9f',1,'Boss::otrzymajObrazenia()'],['../class_gracz.html#ac006d58f6056ad4306783477d080a7c6',1,'Gracz::otrzymajObrazenia()'],['../class_enemy.html#a3f69ec0be2f5bfc1b0fa034ea2e1590e',1,'Enemy::otrzymajObrazenia()']]]
];
