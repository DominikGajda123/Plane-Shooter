var searchData=
[
  ['zakonczono_0',['zakonczono',['../class_eksplozja.html#a02361b1b3822da636d903f36d27a0b4d',1,'Eksplozja']]],
  ['zasoby_1',['zasoby',['../class_gra.html#a1715d08748255911f81846e43fd723dc',1,'Gra']]],
  ['zycia_2',['zycia',['../class_gracz.html#a292f1d8206e4ec48f5be43471dc9c950',1,'Gracz']]]
];
