var searchData=
[
  ['maxhp_0',['maxHp',['../class_boss.html#a1837495e48c9d31b2615d54ea8f951e8',1,'Boss']]],
  ['maxzycia_1',['maxZycia',['../class_gracz.html#aa7a1e4c5112dae462a8e5baafdc0502d',1,'Gracz']]],
  ['muzyka_2',['muzyka',['../class_gra.html#a0b0ad903c2422a26ae3356ff56119566',1,'Gra']]]
];
