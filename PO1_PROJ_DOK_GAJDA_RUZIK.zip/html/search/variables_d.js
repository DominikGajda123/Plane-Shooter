var searchData=
[
  ['pociski_0',['pociski',['../class_gra.html#a35c44b38eb67dfda7b5a6f17640f614d',1,'Gra']]],
  ['pociskiwrogow_1',['pociskiWrogow',['../class_gra.html#ab5ec10df67523d8222786ae356fe93bc',1,'Gra']]],
  ['podwojnystrzal_2',['podwojnyStrzal',['../class_gra.html#af7fbb2fd28a248c96c3080b435a9f829',1,'Gra']]],
  ['predkosc_3',['predkosc',['../class_gracz.html#a757b01d6bfe711a908b8c7d8b7d9d49e',1,'Gracz::predkosc'],['../class_pocisk_bazowy.html#a218f34818bf1a66152759bab3b95c438',1,'PociskBazowy::predkosc'],['../class_enemy.html#adc5332139c6f90fae9e66d52fcb54e0c',1,'Enemy::predkosc'],['../struct_ulepszenie.html#aea62494c49f4f999f2c18abbff84582e',1,'Ulepszenie::predkosc']]],
  ['predkoscx_4',['predkoscX',['../class_boss.html#a5519ce096ccc5dc1cd1b65db6f6450e2',1,'Boss']]],
  ['przeciwnicy_5',['przeciwnicy',['../class_gra.html#a94de3f01bb46a3f91c17cc6c340514d6',1,'Gra']]]
];
