var searchData=
[
  ['ulepszenie_0',['Ulepszenie',['../struct_ulepszenie.html',1,'']]]
];
