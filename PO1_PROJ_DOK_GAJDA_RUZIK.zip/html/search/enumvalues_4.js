var searchData=
[
  ['tarcza_0',['Tarcza',['../_ulepszenie_8h.html#af39aa1cab4aeea2c0c1468bda978b257a4d0e40f54b8dd8601cb225c3165ffbfe',1,'Ulepszenie.h']]]
];
