var searchData=
[
  ['zasoby_2ecpp_0',['Zasoby.cpp',['../_zasoby_8cpp.html',1,'']]],
  ['zasoby_2eh_1',['Zasoby.h',['../_zasoby_8h.html',1,'']]]
];
