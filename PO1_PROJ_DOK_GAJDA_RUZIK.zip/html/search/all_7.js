var searchData=
[
  ['hp_0',['hp',['../class_boss.html#a0517628e5cdd82ee25abae40f0fc3b34',1,'Boss::hp'],['../class_enemy.html#a278d70100af07c946743db1b7a1a9f59',1,'Enemy::hp']]]
];
