var searchData=
[
  ['dezaktywuj_0',['dezaktywuj',['../class_pocisk_bazowy.html#a6dfe140d285f07503404e1b397a4d896',1,'PociskBazowy']]],
  ['dodajeksplozje_1',['dodajEksplozje',['../class_gra.html#a70375c73de09aed942b6360579c3a778',1,'Gra']]]
];
