var searchData=
[
  ['cooldownkolizji_0',['cooldownKolizji',['../class_gra.html#ac6a06e06aa6f6d8d407b7515d37b940a',1,'Gra']]],
  ['cooldownspawnu_1',['cooldownSpawnu',['../class_gra.html#a2dce523db75128beb27b6895087cc296',1,'Gra']]],
  ['cooldownstrzalu_2',['cooldownStrzalu',['../class_gra.html#a5ec9d6e650dbdc3d904fdcf8338da2b6',1,'Gra']]],
  ['cooldownstrzalubossa_3',['cooldownStrzaluBossa',['../class_gra.html#a0389ecf726e086cbc42511ee25ec9185',1,'Gra']]],
  ['cooldownstrzaluwroga_4',['cooldownStrzaluWroga',['../class_gra.html#a63a975a7d4caf0a898c754b7f7ec155b',1,'Gra']]],
  ['czas_5',['czas',['../class_eksplozja.html#aefa73c6625c5f7371bc71da4cb9609de',1,'Eksplozja']]],
  ['czasklatki_6',['czasKlatki',['../class_eksplozja.html#a7f134a1e61b9e80549c1e0974b04a753',1,'Eksplozja']]],
  ['czyaktywny_7',['czyAktywny',['../class_pocisk_bazowy.html#ab9cf85d8987ba74ac95be2dee4614292',1,'PociskBazowy']]],
  ['czymartwy_8',['czyMartwy',['../class_boss.html#ab3709c49651f38fffd6b7341a560eb47',1,'Boss::czyMartwy()'],['../class_enemy.html#a1790768f87e6f6ec9bd03307d12c247f',1,'Enemy::czyMartwy()']]],
  ['czyulepszeniedostepne_9',['czyUlepszenieDostepne',['../class_gra.html#a903996afc3794aa4fd2e14a925ac7533',1,'Gra']]],
  ['czyzakonczona_10',['czyZakonczona',['../class_eksplozja.html#adf687c10e9fbeea0d20b819f5d9e9717',1,'Eksplozja']]]
];
