var searchData=
[
  ['aktualnaklatka_0',['aktualnaKlatka',['../class_eksplozja.html#a284225b99b720d9f31ea42100edc5a73',1,'Eksplozja']]],
  ['aktywne_1',['aktywne',['../struct_ulepszenie.html#a7fbf8d5537cda8f30a411321af251896',1,'Ulepszenie']]],
  ['aktywny_2',['aktywny',['../class_pocisk_bazowy.html#a99cf2793e71d35c00219bb03d9b33439',1,'PociskBazowy']]]
];
