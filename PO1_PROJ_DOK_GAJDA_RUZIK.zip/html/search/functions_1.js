var searchData=
[
  ['boss_0',['Boss',['../class_boss.html#a7be7ddd42c69cd75032b1956eab7db88',1,'Boss']]]
];
