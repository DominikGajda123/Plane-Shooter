var searchData=
[
  ['zasoby_0',['Zasoby',['../class_zasoby.html',1,'']]]
];
