var searchData=
[
  ['gameover_0',['gameOver',['../class_gra.html#a765b998bc8da9ea3f6a60832051b6079',1,'Gra']]],
  ['gracz_1',['gracz',['../class_gra.html#ad4850e46c2aca3fbc025626b2b9cdd82',1,'Gra']]]
];
