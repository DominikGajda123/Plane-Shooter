var searchData=
[
  ['licznikkolizji_0',['licznikKolizji',['../class_gra.html#ab2e7208612105928aefd80f6987a7351',1,'Gra']]],
  ['licznikspawnu_1',['licznikSpawnu',['../class_gra.html#a02e855c55dab847d4b7637b03038e6c4',1,'Gra']]],
  ['licznikstrzalu_2',['licznikStrzalu',['../class_gra.html#ab1c1c43c868cf1b783bc563021618b1f',1,'Gra']]],
  ['licznikstrzalubossa_3',['licznikStrzaluBossa',['../class_gra.html#a93f3ec4d5e761bf1b7425e1b84ba9f21',1,'Gra']]],
  ['licznikstrzaluwroga_4',['licznikStrzaluWroga',['../class_gra.html#a9b41b4e955a69479a1ca450d3fe01ed7',1,'Gra']]],
  ['losujint_5',['losujInt',['../class_gra.html#a3a19fd4fd8d81cee8a393421fb4e8985',1,'Gra']]]
];
