var searchData=
[
  ['font_0',['font',['../class_gra.html#a04d3538b7e54f6debc37df59837cf548',1,'Gra']]]
];
