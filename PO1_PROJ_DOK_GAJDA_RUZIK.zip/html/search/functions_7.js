var searchData=
[
  ['matarcze_0',['maTarcze',['../class_gracz.html#a5d0b427098e06c8c1bb7c7a854eb3729',1,'Gracz']]]
];
